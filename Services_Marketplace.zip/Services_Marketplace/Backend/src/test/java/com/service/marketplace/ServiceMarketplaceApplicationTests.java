//package com.service.marketplace;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class ServiceMarketplaceApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}

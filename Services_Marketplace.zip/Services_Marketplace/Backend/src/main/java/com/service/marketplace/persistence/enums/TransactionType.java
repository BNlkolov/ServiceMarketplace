package com.service.marketplace.persistence.enums;

public enum TransactionType {
    SUBSCRIPTION,
    PAYMENT
}

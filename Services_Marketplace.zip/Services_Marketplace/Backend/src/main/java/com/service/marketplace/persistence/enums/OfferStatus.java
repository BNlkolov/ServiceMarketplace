package com.service.marketplace.persistence.enums;

public enum OfferStatus {
    ACCEPTED,
    DECLINED,
    PENDING,
}

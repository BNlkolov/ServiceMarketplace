package com.service.marketplace.persistence.enums;

public enum Type {
}

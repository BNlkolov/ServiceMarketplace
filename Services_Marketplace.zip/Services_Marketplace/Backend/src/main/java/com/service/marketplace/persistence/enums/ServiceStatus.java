package com.service.marketplace.persistence.enums;

public enum ServiceStatus {
    ACTIVE,
    INACTIVE
}

package com.service.marketplace.persistence.enums;

public enum SourceType {
    SERVICE,
    REVIEW
}

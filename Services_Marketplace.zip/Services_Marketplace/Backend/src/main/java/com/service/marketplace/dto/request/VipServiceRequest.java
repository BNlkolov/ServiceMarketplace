package com.service.marketplace.dto.request;

public class VipServiceRequest {
    private Integer serviceId;
    private String startDate;
    private String endDate;
    private boolean isActive;
    private String stripeId;
}

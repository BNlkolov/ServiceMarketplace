package com.service.marketplace.config;

public class UserConfig {

}

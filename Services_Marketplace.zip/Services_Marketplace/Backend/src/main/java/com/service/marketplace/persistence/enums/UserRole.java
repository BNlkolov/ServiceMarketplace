package com.service.marketplace.persistence.enums;

public enum UserRole {

    ADMIN,
    PROVIDER,
    CUSTOMER
}

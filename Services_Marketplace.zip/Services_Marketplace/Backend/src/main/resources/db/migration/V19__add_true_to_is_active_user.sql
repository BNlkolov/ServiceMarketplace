UPDATE user
SET is_active = 1;
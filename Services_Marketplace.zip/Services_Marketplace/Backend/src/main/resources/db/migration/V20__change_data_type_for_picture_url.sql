ALTER TABLE user
MODIFY COLUMN picture varchar(1000);

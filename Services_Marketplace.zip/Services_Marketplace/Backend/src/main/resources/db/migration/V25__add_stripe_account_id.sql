ALTER TABLE user
add column stripe_account_id varchar(50);
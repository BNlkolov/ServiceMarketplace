ALTER TABLE user
add column media_key varchar(1000);

ALTER TABLE user
ADD COLUMN reset_password_token VARCHAR(45);
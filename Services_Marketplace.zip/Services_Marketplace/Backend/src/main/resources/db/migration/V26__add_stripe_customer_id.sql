ALTER TABLE user
add column stripe_customer_id varchar(50);
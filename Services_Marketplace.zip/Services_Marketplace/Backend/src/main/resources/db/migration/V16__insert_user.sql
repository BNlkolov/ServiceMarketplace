INSERT INTO user (first_name, last_name, email, password, phone_number, experience, rating, description, picture)
VALUES ('John', 'Doe', 'john.doe@example.com', 'password123', 1234567890, 5, 4.5, 'Experienced developer', 'mock_picture_data');

INSERT INTO user (first_name, last_name, email, password, phone_number, experience, rating, description, picture)
VALUES ('Jane', 'Smith', 'jane.smith@example.com', 'pass456', 9876543210, 3, 3.8, 'Front-end developer', 'mock_picture_data');

INSERT INTO user (first_name, last_name, email, password, phone_number, experience, rating, description, picture)
VALUES ('Bob', 'Johnson', 'bob.johnson@example.com', 'securepass', 5555555555, 7, 4.2, 'Full-stack developer', 'mock_picture_data');

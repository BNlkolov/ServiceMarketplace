alter table offer
add column stripe_product_id varchar(255);

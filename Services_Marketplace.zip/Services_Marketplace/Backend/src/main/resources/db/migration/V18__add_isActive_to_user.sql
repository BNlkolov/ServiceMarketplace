ALTER TABLE user
add column is_active BOOLEAN;
ALTER TABLE subscription
add column is_cancelled BOOLEAN;